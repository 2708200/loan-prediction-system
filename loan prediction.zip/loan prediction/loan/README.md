# loan_prediction machine learning project

Lecture for these project
[youtube link ](https://www.youtube.com/playlist?list=PLA0J2h1KIAR7xoDbI1usGLVRW6_6qiLuq)
